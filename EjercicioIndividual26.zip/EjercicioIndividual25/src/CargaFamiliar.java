public class CargaFamiliar {
 //Se declaran las constantes según parentesco
  public final int CONYUGUE = 1;
  public final int HIJO = 2;
  public final int OTRO = 3;

  //Se declaran las variables de la carga familiar.
  private String runCarga;
  private String nombresCarga;
  private String apellidosCarga;
  private String runFamiliar;
  private int parentesco;
  private int edad;

  //setters and getters
  public String getRunCarga() {
    return runCarga;
  }

  public void setRunCarga(String runCarga) {
    this.runCarga = runCarga;
  }

  public String getNombresCarga() {
    return nombresCarga;
  }

  public void setNombresCarga(String nombresCarga) {
    this.nombresCarga = nombresCarga;
  }

  public String getApellidosCarga() {
    return apellidosCarga;
  }

  public void setApellidosCarga(String apellidosCarga) {
    this.apellidosCarga = apellidosCarga;
  }

  public String getRunFamiliar() {
    return runFamiliar;
  }

  public void setRunFamiliar(String runFamiliar) {
    this.runFamiliar = runFamiliar;
  }

  public int getParentesco() {
    return parentesco;
  }

  public void setParentesco(int parentesco) {
    this.parentesco = parentesco;
  }

  public int getEdad() {
    return edad;
  }

  public void setEdad(int edad) {
    this.edad = edad;
  }

  //Constructores
  public CargaFamiliar() {
  }

  public CargaFamiliar(String runCarga, String nombresCarga, String apellidosCarga,
                       String runFamiliar, int parentesco, int edad) {
    this.runCarga = runCarga;
    this.nombresCarga = nombresCarga;
    this.apellidosCarga = apellidosCarga;
    this.runFamiliar = runFamiliar;
    this.parentesco = parentesco;
    this.edad = edad;
  }

  //Método toString
  @Override
  public String toString() {
    return "CargaFamiliar{" +
            "runCarga='" + runCarga + '\'' +
            ", nombresCarga='" + nombresCarga + '\'' +
            ", apellidosCarga='" + apellidosCarga + '\'' +
            ", runFamiliar='" + runFamiliar + '\'' +
            ", parentesco=" + parentesco +
            ", edad=" + edad +
            '}';
  }
}
